import random
import json
from collections import defaultdict

data = open("action_recognition_cot.jsonl", "r").readlines()
balanced_indices = []
labels = []
label2indices = defaultdict(list)
for sample_index, sample in enumerate(data):
    sample = json.loads(sample)
    label = sample["conversations"][-1]["value"].split("Final answer:")[-1].strip()
    label2indices[label].append(sample_index)
    labels.append(label)

for label, indices in label2indices.items():
    print(f"Label: {label}, Count: {len(indices)}")

max_class_size = max(len(indices) for indices in label2indices.values())
min_class_size = min(len(indices) for indices in label2indices.values())
print(f"Max class size: {max_class_size}, Min class size: {min_class_size}")
for label, indices in label2indices.items():
    if len(indices) < max_class_size:
        sampled = random.choices(indices, k=max_class_size)
    else:
        sampled = random.sample(indices, max_class_size)
    balanced_indices.extend(sampled)

print(f"Total balanced samples: {len(balanced_indices)}")
# balanced_data = [data[i] for i in balanced_indices]
# with open("balanced_action_recognition_cot.jsonl", "w") as f:
#     f.writelines(balanced_data)
